//
//  MyExpriceObj.h
//  studyobjc4
//
//  Created by apple on 2020/3/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyExpriceObj : NSObject
+ (void)studyObjSize;


@end

NS_ASSUME_NONNULL_END
